'''
Demo code for imaging through turbulence simulation

Z. Mao, N. Chimitt, and S. H. Chan, "Accerlerating Atmospheric Turbulence 
Simulation via Learned Phase-to-Space Transform", ICCV 2021

Arxiv: https://arxiv.org/abs/2107.11627

Zhiyuan Mao, Nicholas Chimitt, and Stanley H. Chan
Copyright 2021
Purdue University, West Lafayette, IN, USA
'''

# Added video reader functionality

from simulator import Simulator
from turbStats import tilt_mat, corr_mat, get_r0
import matplotlib.pyplot as plt
import torch
import cv2
import io
import os

# Set variables
D = 0.10
L = 2000
# r0 can either be calculated from Cn2 and L using the get_r0 function, or stated: 
Cn2 = 1.0e-15
r0 = get_r0(Cn2, L)
# r0 = 0.5


# Select device.
device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('CPU')


'''
The corr_mat function is used to generate spatial-temporal correlation matrix 
for point spread functions. It may take over 10 minutes to finish. However, 
for each correlation value, it only needs to be computed once and can be 
used for all D/r0 values. You can also download the pre-generated correlation
matrix from our website. 
https://engineering.purdue.edu/ChanGroup/project_turbulence.html
'''

# Uncomment the following line to generate correlation matrix
# corr_mat(-0.1,'./data/')


# Instead of loading external image, use video frames from a SQUARE video
nameOfTheVideo = '512x512Video.avi'

cap = cv2.VideoCapture(nameOfTheVideo)
video_name = os.path.splitext(os.path.basename(nameOfTheVideo))[0]
frame_count = 0

vidLength = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
frame_rate = cap.get(cv2.CAP_PROP_FPS)
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
output_directory = f"{video_name}_frames"
os.makedirs(output_directory, exist_ok=True)

# Generate correlation matrix for tilt. Do this once for each different turbulence parameter. 
tilt_mat(frame_width, D, r0, L)





while cap.isOpened():
    ret, x = cap.read()
    if not ret:
        break
     
    # Load image, permute axis if color
    # x = cv2.imread('./images/color.png')
    # x = plt.imread('./images/color.png')

    if len(x.shape) == 3: 
        x = x.transpose((2,0,1))
    x = torch.tensor(x, device = device, dtype=torch.float32)

    im_size = x.shape[1] # The current version works for square image only

    # Simulate. 
    simulator = Simulator(D/r0, im_size).to(device, dtype=torch.float32)

    # Note that the current version does not support batched images. Only one frame at a time. 
    out = simulator(x).detach().cpu().numpy()

    if len(out.shape) == 3: 
        out = out.transpose((1,2,0))

    # save image
    # plt.imshow(out)
    # plt.imsave('./images/out.png',out)
    #cv2.imwrite('./images/out.png', out)

    frame_count += 1
        
    # Only extract frames at the desired frame rate
    if frame_count % int(cap.get(5) / frame_rate) == 0:
        output_file = f"{output_directory}/frame_{frame_count}.jpg"
        cv2.imwrite(output_file, out)

cap.release()





